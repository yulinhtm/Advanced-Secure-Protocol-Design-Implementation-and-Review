# ClientCommands.py
"""
ClientCommands - implements /list, /tell, /file according to SOCP (secure variant).
- get_recipient_pubkey reads pubkey from local SQLite 'user.db' users.pubkey (base64url DER).
- do_tell signs content_sig = PSS-SHA256( SHA256(ciphertext_b64 || from || to || ts) )
- do_file signs manifest and each chunk (chunk_sig) over canonical JSON of chunk-info.
"""

import os
import uuid
import time
import json
import base64
import hashlib
import sqlite3
import asyncio
from typing import Optional

import crypto_utils as cu

MAX_RSA_PLAINTEXT = 446  # RSA-4096 OAEP SHA-256 max plaintext bytes

def _b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode('utf-8').rstrip('=')

def _b64url_decode(s: str) -> bytes:
    padding = '=' * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + padding)

def _now_ms() -> int:
    return int(time.time() * 1000)

class ClientCommands:
    def __init__(self, ws, user_id: str, privkey, db_path: str = "user.db"):

        self.ws = ws
        self.user_id = user_id
        self.privkey = privkey
        self.db_path = db_path

    # ---------------- helper: lookup recipient public key from local DB ----------------
    def get_recipient_pubkey_sync(self, recipient_id: str):
        """
        Synchronous retrieval helper used by async wrapper.
        Expects table `users` with column `pubkey` storing base64url DER.
        Returns cryptography RSAPublicKey.
        Raises ValueError if not found or parse fails.
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.cursor()
                cur.execute("SELECT pubkey FROM users WHERE user_id = ?", (recipient_id,))
                row = cur.fetchone()
                if not row:
                    raise ValueError(f"Pubkey for {recipient_id} not found in {self.db_path}")
                pub_b64 = row[0]
                # use crypto_utils to deserialize
                pubkey = cu.deserialize_publickey(pub_b64)
                return pubkey
        except sqlite3.Error as e:
            raise ValueError(f"DB error while fetching pubkey for {recipient_id}: {e}")

    async def get_recipient_pubkey(self, recipient_id: str):
        """
        Async wrapper; currently performs synchronous DB I/O.
        You may replace this with an async DB call or a server query.
        """
        return self.get_recipient_pubkey_sync(recipient_id)

    # ---------------- /list ----------------
    async def do_list(self):
        env = {
            "type": "LIST_REQUEST",
            "from": self.user_id,
            "to": "*",
         "ts": cu.int_ts_ms(),
            "payload": {}
        }
        await self.ws.send(json.dumps(env))
        print("[CLIENT] /list 已发送")

    # ---------------- /tell (end-to-end) ----------------
    async def do_tell(self, recipient_id: str, plaintext: str, recipient_pub=None):
        if recipient_pub is None:
            recipient_pub = await self.get_recipient_pubkey(recipient_id)
        if recipient_pub is None:
            raise ValueError("recipient public key unavailable")

        # 加密正文
        ciphertext = cu.rsa_oaep_encrypt(recipient_pub, plaintext.encode("utf-8"))
        # 用统一工具做 base64url
        ciphertext_b64 = cu.b64url_encode(ciphertext)

        # 用这些值做签名（并随 payload 一起发送，避免被服务器改 envelope 影响）
        sig_from = self.user_id
        sig_to   = recipient_id
        sig_ts   = _now_ms()

        # sign( SHA256(ciphertext_b64 || sig_from || sig_to || sig_ts) )
        digest = hashlib.sha256(
            (ciphertext_b64 + sig_from + sig_to + str(sig_ts)).encode("utf-8")
        ).digest()
        content_sig = cu.sign_payload(self.privkey, digest)

        payload = {
            "ciphertext": ciphertext_b64,
            "sender_pub": cu.serialize_publickey(self.privkey.public_key()),
            "content_sig": content_sig,
            # 新增三字段：用于接收端复原同一签名输入
            "sig_from": sig_from,
            "sig_to":   sig_to,
            "sig_ts":   sig_ts,
        }

        env = {
            "type": "MSG_DIRECT",
            "from": self.user_id,
            "to": recipient_id,
            "ts": _now_ms(),   # envelope 的 ts 不参与签名，无所谓
            "payload": payload
        }
        await self.ws.send(json.dumps(env))


   # ---------------- /file (manifest + chunk_sig) ----------------
async def do_file(self, recipient_id: str, filepath: str, recipient_pub=None, mode: str = "dm"):
    """
    Send file in three phases:
      FILE_START: manifest + manifest_sig (canonical JSON signed)
      FILE_CHUNK: ciphertext (RSA-OAEP using recipient_pub) + chunk_sig (PSS over canonical JSON of chunk info)
      FILE_END
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(filepath)

    # 1) 获取对方公钥
    if recipient_pub is None:
        recipient_pub = await self.get_recipient_pubkey(recipient_id)
    if recipient_pub is None:
        raise ValueError("recipient public key unavailable")

    # 2) 基本元数据 & 整文件 sha256
    file_id = str(uuid.uuid4())             # 规范建议用 UUIDv4
    name    = os.path.basename(filepath)
    size    = os.path.getsize(filepath)

    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    sha256_hex = h.hexdigest()

    # 3) manifest + manifest_sig（对 canonical_json(manifest) 签名）
    manifest = {
        "file_id": file_id,
        "name":    name,
        "size":    size,
        "sha256":  sha256_hex,   # ★ 新增：整文件哈希（十六进制）
        "mode":    mode
    }
    manifest_bytes = cu.canonical_json(manifest).encode("utf-8")
    manifest_sig   = cu.sign_payload(self.privkey, manifest_bytes)

    start_msg = {
        "type": "FILE_START",
        "from": self.user_id,
        "to":   recipient_id,
        "ts":   _now_ms(),
        "payload": {
            **manifest,
            "manifest_sig": manifest_sig,
            "sender_pub":   cu.serialize_publickey(self.privkey.public_key())
        }
    }
    await self.ws.send(json.dumps(start_msg))

    # 4) 逐块加密发送（每块都签 {file_id,index,ciphertext}）
    with open(filepath, "rb") as f:
        idx = 0
        while True:
            chunk = f.read(MAX_RSA_PLAINTEXT)
            if not chunk:
                break

            ciph    = cu.rsa_oaep_encrypt(recipient_pub, chunk)
            ciph_b64 = _b64url_encode(ciph)

            chunk_info = {"file_id": file_id, "index": idx, "ciphertext": ciph_b64}
            chunk_sig  = cu.sign_payload(self.privkey, cu.canonical_json(chunk_info).encode("utf-8"))

            chunk_msg = {
                "type": "FILE_CHUNK",
                "from": self.user_id,
                "to":   recipient_id,
                "ts":   _now_ms(),
                "payload": {
                    "file_id":    file_id,
                    "index":      idx,
                    "ciphertext": ciph_b64,
                    "chunk_sig":  chunk_sig
                }
            }
            await self.ws.send(json.dumps(chunk_msg))
            idx += 1

    # 5) 结束帧
    end_msg = {
        "type": "FILE_END",
        "from": self.user_id,
        "to":   recipient_id,
        "ts":   _now_ms(),
        "payload": {"file_id": file_id}
    }
    await self.ws.send(json.dumps(end_msg))

    # ---------------- optional demo /all (UNSAFE) ----------------
    async def do_all_demo_broadcast(self, plaintext: str, group_id: str = "public"):
        """
        DEMO ONLY: broadcast plaintext (not secure). Prefer implementing channel keys.
        """
        ts = _now_ms()
        payload = {
            "plaintext": plaintext,
            "sender_pub": cu.serialize_publickey(self.privkey.public_key())
        }
        env = {
            "type": "MSG_PUBLIC_CHANNEL",
            "from": self.user_id,
            "to": group_id,
            "ts": ts,
            "payload": payload
        }
        await self.ws.send(json.dumps(env))

    # ---------------- low-level send ----------------
    async def send_envelope(self, env: dict, attach_transport_sig: bool = False):
        """
        If attach_transport_sig True: attach env['sig'] = sign(canonical_json(payload))
        """
        if attach_transport_sig:
            env["sig"] = cu.sign_payload(self.privkey, cu.canonical_json(env.get("payload", {})).encode('utf-8'))
        await self.ws.send(json.dumps(env))