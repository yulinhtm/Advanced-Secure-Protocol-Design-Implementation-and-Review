# Advanced-Secure-Protocol-Design-Implementation-and-Review

Grope member:

Jiahui Wang a1822691

Yuxuan Wu a1898143

ShunChit Yu a1880719

Network protocol: Websocket  
Encrytion: RSA  
public channel  
Json file Style: SOCP(read SOCP V1.3.pdf for more details)  

file:
crypto_utils.py     --for function that will be used in client and server  
TestingClient.py    --being the client Side  
TestingServer.py    --being the server side(do all the coomincation work)  
SOCP v1.3.pdf       -- about everything in socp protocol  
image.webp          -- show libaray that can be used to appy websock for different language(i choose websockts(python))  

Other file can be ignored  


