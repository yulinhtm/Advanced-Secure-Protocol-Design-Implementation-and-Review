import os
import time
import json
import base64
import hashlib
import sqlite3
import asyncio
from typing import Optional

import crypto_utils as cu

RSA_PLAINTEXT_LIMIT = 446  # RSA-4096 OAEP SHA-256 max plaintext bytes

def _b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode('utf-8').rstrip('=')

def _b64url_decode(s: str) -> bytes:
    padding = '=' * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + padding)

def _now_ms() -> int:
    return int(time.time() * 1000)

class ClientCommands:
    def __init__(self, ws, user_id: str, privkey, db_path: str = "user.db"):

        self.ws = ws
        self.user_id = user_id
        self.privkey = privkey
        self.db_path = db_path

    # ---------------- helper: lookup recipient public key from local DB ----------------
    def get_recipient_pubkey_sync(self, recipient_id: str):
        """
        Synchronous retrieval helper used by async wrapper.
        Expects table `users` with column `pubkey` storing base64url DER.
        Returns cryptography RSAPublicKey.
        Raises ValueError if not found or parse fails.
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.cursor()
                cur.execute("SELECT pubkey FROM users WHERE user_id = ?", (recipient_id,))
                row = cur.fetchone()
                if not row:
                    raise ValueError(f"Pubkey for {recipient_id} not found in {self.db_path}")
                pub_b64 = row[0]
                # use crypto_utils to deserialize
                pubkey = cu.deserialize_publickey(pub_b64)
                return pubkey
        except sqlite3.Error as e:
            raise ValueError(f"DB error while fetching pubkey for {recipient_id}: {e}")

    async def get_recipient_pubkey(self, recipient_id: str):
        """
        Async wrapper; currently performs synchronous DB I/O.
        You may replace this with an async DB call or a server query.
        """
        return self.get_recipient_pubkey_sync(recipient_id)

    # ---------------- /list ----------------
    async def do_list(self, user_list):
        print(user_list)
        env = {
            "type": "LIST_REQUEST",
            "from": self.user_id,
            "to": "*",
         "ts": cu.int_ts_ms(),
            "payload": {}
        }
        await self.ws.send(json.dumps(env))
        print("[CLIENT] /list 已发送")

    # ---------------- /tell (end-to-end) ----------------
    async def do_tell(self, recipient_id: str, plaintext: str, recipient_pub_str=None):

        if recipient_pub_str is None:
            raise ValueError("recipient public key unavailable")
        recipient_pub = cu.deserialize_publickey(recipient_pub_str)

        # 加密正文
        ciphertext = cu.rsa_oaep_encrypt(recipient_pub, plaintext.encode("utf-8"))
        # 用统一工具做 base64url
        ciphertext_b64 = cu.b64url_encode(ciphertext)

        # 用这些值做签名（并随 payload 一起发送，避免被服务器改 envelope 影响）
        sig_from = self.user_id
        sig_to   = recipient_id
        sig_ts   = _now_ms()

        # sign( SHA256(ciphertext_b64 || sig_from || sig_to || sig_ts) )
        digest = hashlib.sha256(
            (ciphertext_b64 + sig_from + sig_to + str(sig_ts)).encode("utf-8")
        ).digest()
        content_sig = cu.sign_payload(self.privkey, digest)

        payload = {
            "ciphertext": ciphertext_b64,
            "sender_pub": cu.serialize_publickey(self.privkey.public_key()),
            "content_sig": content_sig,
            "sig_from": sig_from,
            "sig_to":   sig_to,
            "sig_ts":   sig_ts,
        }

        env = {
            "type": "MSG_DIRECT",
            "from": self.user_id,
            "to": recipient_id,
            "ts": _now_ms(),  
            "payload": payload
        }
        await self.ws.send(json.dumps(env))


    # ---------------- /file (DM + RSA) ----------------
    async def do_file(self, recipient_id: str, filepath: str, recipient_pub_str=None):

        if recipient_pub_str is None:
            raise ValueError("recipient public key unavailable")
        recipient_pub = cu.deserialize_publickey(recipient_pub_str)
        
        if not os.path.exists(filepath):
            raise FileNotFoundError(filepath)

        # 拿接收方公钥
        if recipient_pub is None:
            raise ValueError("recipient public key unavailable")

        file_id = str(time.time_ns())
        name    = os.path.basename(filepath)
        size    = os.path.getsize(filepath)

        # --- 1) 发送 FILE_START：清单 + 签名 ---
        manifest = {
            "file_id": file_id,
            "name":    name,
            "size":    size,
            "mode":    "dm-rsa",           # 标注模式，便于调试
            "chunk":   RSA_PLAINTEXT_LIMIT # 告知对端用多大分块（明文）
        }
        manifest_sig = cu.sign_payload(self.privkey, cu.canonical_json(manifest).encode("utf-8"))

        start_msg = {
            "type": "FILE_START",
            "from": self.user_id,
            "to":   recipient_id,
            "ts":   cu.int_ts_ms(),
            "payload": {
                **manifest,
                "manifest_sig": manifest_sig,
                "sender_pub":   cu.serialize_publickey(self.privkey.public_key()),
            }
        }
        await self.ws.send(json.dumps(start_msg))

        # --- 2) 按 RSA 上限分块，加密后发送 FILE_CHUNK ---
        sent = 0
        with open(filepath, "rb") as f:
            idx = 0
            while True:
                plain = f.read(RSA_PLAINTEXT_LIMIT)
                if not plain:
                    break

                ciph     = cu.rsa_oaep_encrypt(recipient_pub, plain)
                ciph_b64 = cu.b64url_encode(ciph)

                # 对块做签名：对 {file_id,index,ciphertext} 的 canonical JSON 做 RSASSA-PSS
                chunk_info = {"file_id": file_id, "index": idx, "ciphertext": ciph_b64}
                chunk_sig  = cu.sign_payload(self.privkey, cu.canonical_json(chunk_info).encode("utf-8"))

                chunk_msg = {
                    "type": "FILE_CHUNK",
                    "from": self.user_id,
                    "to":   recipient_id,
                    "ts":   cu.int_ts_ms(),
                    "payload": {
                        **chunk_info,
                        "chunk_sig": chunk_sig
                    }
                }
                await self.ws.send(json.dumps(chunk_msg))
                sent += len(plain)
                idx  += 1

        # --- 发送 FILE_END ---
        end_msg = {
            "type": "FILE_END",
            "from": self.user_id,
            "to":   recipient_id,
            "ts":   cu.int_ts_ms(),
            "payload": {"file_id": file_id}
        }
        await self.ws.send(json.dumps(end_msg))
        print(f"[/file] Sent {name} ({size} bytes) to {recipient_id} (DM-RSA)")

    async def do_all(self, plaintext: str, group_id: str = "public"):
        """
        /all - AES-GCM 加密的公共频道消息（SOCP §12: sign SHA256(ciphertext||from||ts)）
        说明：这一步只更换成密文格式；还未分发 AES 密钥（Key Share）。
        """
        ts = cu.int_ts_ms()
        from_uid = self.user_id

        # 生成一次性 AES-256 密钥与 12 字节随机 IV
        aes_key = os.urandom(32)   # 256-bit
        iv      = os.urandom(12)   # GCM 推荐 96-bit IV

        # 加密
        ct, tag = cu.aes_gcm_encrypt(aes_key, iv, plaintext.encode("utf-8"))

        # content_sig：对密文签名（公共频道没有单一 to，按 §12 使用 ciphertext||from||ts）
        ct_b64 = cu.b64url_encode(ct)
        dg     = hashlib.sha256((ct_b64 + from_uid + str(ts)).encode("utf-8")).digest()
        content_sig = cu.sign_payload(self.privkey, dg)

        payload = {
            "ciphertext":  ct_b64,
            "iv":          cu.b64url_encode(iv),
            "tag":         cu.b64url_encode(tag),
            "sender_pub":  cu.serialize_publickey(self.privkey.public_key()),
            "content_sig": content_sig,
            "sig_from":    from_uid,
            "sig_ts":      ts,

            # 预留：key share（下一步实现时填充）
            # "shares": { "<user_id>": "<rsa_oaep(aes_key) b64url>" , ... }
        }

        env = {
            "type": "MSG_PUBLIC_CHANNEL",
            "from": from_uid,
            "to":   group_id,
            "ts":   ts,
            "payload": payload
        }
        await self.ws.send(json.dumps(env))
        print(f"[/all] 已广播到 {group_id}（AES-GCM 密文；尚未分发 key）")

    # ---------------- low-level send ----------------
    async def send_envelope(self, env: dict, attach_transport_sig: bool = False):
        """
        If attach_transport_sig True: attach env['sig'] = sign(canonical_json(payload))
        """
        if attach_transport_sig:
            env["sig"] = cu.sign_payload(self.privkey, cu.canonical_json(env.get("payload", {})).encode('utf-8'))
        await self.ws.send(json.dumps(env))
